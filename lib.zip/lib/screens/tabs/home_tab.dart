import 'package:flutter/material.dart';

import '../../core/routes.dart';
import '../../data/landmarks.dart';
import '../../state/app_scope.dart';
import '../../widgets/app_photo.dart';
import '../../widgets/landmark_card.dart';
import '../../widgets/menu_tile.dart';
import '../../widgets/page_list.dart';
import '../../widgets/section_title.dart';

class HomeTab extends StatelessWidget {
  const HomeTab({super.key, required this.onSelectTab});

  /// Переключает вкладку нижней навигации (1 = карта, 2 = каталог).
  final ValueChanged<int> onSelectTab;

  @override
  Widget build(BuildContext context) {
    final t = AppScope.of(context).t;
    return PageList(
      children: [
        const SectionTitle('QalaChronos'),
        const AppPhoto('city'),
        Text(t('Архитектура сквозь время', 'Уақыт арқылы сәулет', 'Architecture through time')),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          childAspectRatio: 1.25,
          children: [
            MenuTile(
              icon: Icons.map,
              label: t('Карта', 'Карта', 'Map'),
              onTap: () => onSelectTab(1),
            ),
            MenuTile(
              icon: Icons.view_in_ar,
              label: '3D',
              onTap: () => openLandmark(context, landmarks.first),
            ),
            MenuTile(
              icon: Icons.history,
              label: t('Машина времени', 'Уақыт машинасы', 'Time machine'),
              onTap: () => openTimeMachine(context),
            ),
            MenuTile(
              icon: Icons.explore,
              label: t('Каталог', 'Тізім', 'Explore'),
              onTap: () => onSelectTab(2),
            ),
          ],
        ),
        for (final l in landmarks) LandmarkCard(l),
      ],
    );
  }
}
